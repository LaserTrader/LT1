module.exports = {
    bids : [0, 0, 0, 0, 0, 0],
    asks : [0, 0, 0, 0, 0, 0],
}