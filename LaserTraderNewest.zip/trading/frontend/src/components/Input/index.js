import React from 'react'

const Input = () => {
    return (
        <input></input>
    )
}